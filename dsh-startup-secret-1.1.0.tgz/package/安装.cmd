@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ============================================
echo   dsh-startup-secret 安装脚本
echo ============================================
echo.

rem 1. 定位本目录下的 tgz 包
set "TGZ="
for %%f in (dsh-startup-secret-*.tgz) do set "TGZ=%%~ff"
if "%TGZ%"=="" (
  echo [错误] 当前目录没有找到 dsh-startup-secret-*.tgz 安装包。
  echo        请把 tgz 和本脚本放在同一目录后重试。
  pause
  exit /b 1
)
echo 找到安装包: %TGZ%
echo.

rem 2. 定位 dsh 命令（优先 PATH，其次 DeepSeek Harness 内置 CLI）
set "DSH="
where dsh >nul 2>nul && set "DSH=dsh"
if "%DSH%"=="" (
  if exist "%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd" (
    set "DSH=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd"
  )
)
if "%DSH%"=="" (
  echo [错误] 找不到 dsh 命令。
  echo        请先安装 DeepSeek Harness，或把 dsh 加入系统 PATH。
  pause
  exit /b 1
)
echo 使用 dsh: %DSH%
echo.

rem 3. 询问安装到哪个 profile（web / desktop）
set "PROFILE=web"
set /p PROFILE=请输入目标 profile（web / desktop，默认 web）: 
if "%PROFILE%"=="" set "PROFILE=web"
echo.

rem 4. 若安装到 desktop，提示先退出桌面端
if /i "%PROFILE%"=="desktop" (
  echo [提示] 安装到 desktop profile 前，请先完全退出 DeepSeek Harness Desktop
  echo        （含系统托盘图标右键退出），否则写入会被覆盖。
  echo.
  pause
)

rem 5. 执行安装
echo 正在安装到 %PROFILE% profile ...
"%DSH%" plugin --profile %PROFILE% add "%TGZ%"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo ============================================
  echo   安装成功！
  echo   请重启 DSH（%PROFILE%）后刷新页面查看启动动画。
  echo ============================================
) else (
  echo [错误] 安装失败，退出码 %RC%。请检查上方错误信息。
)
echo.
pause
endlocal
